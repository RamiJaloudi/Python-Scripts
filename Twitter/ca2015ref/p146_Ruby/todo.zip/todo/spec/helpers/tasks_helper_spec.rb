#
# describe TasksHelper do
#   describe "string concat" do
#     it "concats two strings with spaces" do
#       helper.concat_strings("this","that").should == "this that"
#     end
#   end
# end
describe TasksHelper do
  describe "task_title_formatter(task)" do
    before do
      @task = Task.new(:title=>"task")
    end
    it "adds a due css class to tasks which are due_soon" do
      @task.due_at = Time.zone.now
      task_title_formatter(@task).should == "<span class='due'>task</span>" #what test to use here?
    end

    it "does not add extra classes to tasks which aren't due soon" do
      @task.due_at = nil
      task_title_formatter(@task).should == "<span>task</span>"
    end
  end
end
