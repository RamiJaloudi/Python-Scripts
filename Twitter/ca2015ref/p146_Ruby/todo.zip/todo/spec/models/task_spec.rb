require 'spec_helper'

describe Task do
  describe "#due_at_is_in_the_past" do
    it "doesn't throw an exception if due_at is nil" do
      lambda {
        Task.new(:due_at=>nil).due_at_is_in_the_past
      }.should_not raise_error
    end
  end


  describe "#due_soon?" do
    it "is true if due in less than 24 hours" do
      task = Task.new(:due_at => Time.zone.now + 23.hour)
      task.should be_due_soon
    end

    it "is false if due in more than 24 hours" do
      task = Task.new(:due_at => Time.zone.now + 25.hour)
      task.should_not be_due_soon
    end

    it "is false if no due date is set" do
      task = Task.new(:due_at => nil)
      task.should_not be_due_soon
    end

    it "is false if the task has been completed" do
      task = Task.new(:due_at => Time.zone.now + 23.hour, :done=>true)
      task.should_not be_due_soon
    end
  end
  
end
