Setup
=====
Although your distro almost certainly has packages available for Ruby we're going to use 'rbenv' to get us up and running. Rbenv allows us to create and manage entirely isolated versions of Ruby inside a user's home environment. Ruby developers use this to hop between different versions of Ruby as projects require, but its main use for us is to avoid touching the root-owned system and ensure we all have a consistent starting point. Start by installing rbenv and ruby-build via the git SCM tool; if you don't have git your package manager will be able to provide it. Open a Terminal and type:

$ git clone git://github.com/sstephenson/rbenv.git ~/.rbenv 

Make your shell aware of rbenv by adding it to your start-up files. If you don't have .bash_profile in your home directory, change the end of the command to ~/.profile, or see the rbenv homepage for help.$ echo 'export PATH="$HOME/.rbenv/bin:$PATH"' >> ~/.bash_profile

Reload your shell, or open a new window and type rbenv - you should see rbenv print itself out. If so, we can now install Ruby: the language underlying Rails.

$ git clone git://github.com/sstephenson/ruby-build.git ~/.rbenv/plugins/ruby-build

$ rbenv install 1.9.3-p392
$ rbenv rehash 

After this, running `ruby --version` should print out the path to Ruby in your ~/.rbenv folder. We'll also be using sqlite3 to store data in later. Your package manager will have a suitable version, e.g.

$ sudo apt-get install sqlite3

Now install the required ruby libraries via bundler

$ bundler install
$ rbenv rehash 
$ rails generate rspec:install

You should now be able to boot the app's server

$ bundle exec rails server

And view the site at http://localhost:3000/tasks
