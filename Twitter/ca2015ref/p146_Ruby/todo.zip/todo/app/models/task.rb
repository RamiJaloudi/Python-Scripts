class Task < ActiveRecord::Base
  attr_accessible :done, :due_at, :notes, :title, :priority
  validates :title, :presence=>true 

  validate :due_at_is_in_the_past, :on=>:create

  def due_at_is_in_the_past
      errors.add(:due_at, 'is in the past!') if (due_at && (due_at < Time.zone.now))
  end

  def due_soon?
    return false if done? or !due_at
    (due_at < Time.zone.now + 24.hours)
  end

end
