# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Todo::Application.config.secret_token = 'c1fb5ad2fe9b8aa56f1cea998cf3fafbc76e5870cd76ddc7699c16a592dcf9098e88c4ce6462f3b0cd4b716ad01312cf946d210fa8824a23326bec801121d445'
