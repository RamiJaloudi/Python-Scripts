module TasksHelper
  def task_title_formatter(task)
    if task.due_soon?
      "<span class='due'>#{task.title}</span>".html_safe
    else
      "<span>#{task.title}</span>".html_safe
    end
  end
end
