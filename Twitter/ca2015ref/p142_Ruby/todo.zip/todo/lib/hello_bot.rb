module HelloBot
  def self.greet(name)
    title = name.split(" ").first
    if ["Miss", "Mr"].include? title
      formal_greeting(name) 
    else
      informal_greeting(name)
    end
  end

  private
  # having the greetings inline as part of the public method was a bit
  # unwieldy, so I refactored them out to be private methods.
  def self.informal_greeting(name)
    "Hi, #{name}"
  end

  def self.formal_greeting(name)
    "How do you do, #{name}?"
  end
end

describe HelloBot do
  describe "#greeting" do

    it "says 'hi' to friends" do
      HelloBot.greet("Bob").should == "Hi, Bob"
    end

    it "is more formal with people whose first name isn't know" do
      HelloBot.greet("Miss Smith").should == "How do you do, Miss Smith?"
    end

    it "Salutes military personnel" do
      pending # remove this line to start testing against this characteristic too
      HelloBot.greet("Captain Blackadder").should == "Atten-shun!"
    end

  end
end

