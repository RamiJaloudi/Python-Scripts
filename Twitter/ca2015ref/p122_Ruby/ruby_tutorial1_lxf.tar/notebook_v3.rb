#!/usr/bin/ruby -w
#
# Final version of notebook program written for Linux Format Ruby 
# tutorial.
# JPK Nov 2012

# Public: class to define a note. 
class Note
  @@notes = 0
  @@notebook_file = 'notebook.txt'

  # Public: Initialize a Note.
  #
  # title - The String title of the Note.
  # body  - The String body of the Note.
  def initialize(title, body)
    @title  = title
    @body   = body
    @@notes += 1
  end
  
  # Public: Generate String version of Note.
  #
  # Returns the String version of the Note.
  def to_s
    "Note: #{title}, #{body}"
  end 

  # Public: Write Note to file.
  #
  # Returns nothing.
  def write_to_file
    nbk = File.open(@@notebook_file, 'a')
    nbk.puts(@title + ',' + @body)
    nbk.close
  end

  # Public: Class method to return total number of Notes created.
  #
  # Returns the Integer number of Notes.
  def self.total_notes
    "Total notes: #{@@notes}"
  end

  # Public: Class method to return name of notebook file.
  #
  # Returns the String name of the notebook file.
  def self.notebook_file
    @@notebook_file
  end

  # Public: Gets/Sets the String title and body of the Note.
  attr_accessor :title, :body
end

myNote = Note.new('Note 1', 'this is a note')
myNote.write_to_file

nbk = File.open(Note.notebook_file, 'r')
while line = nbk.gets do
  note = line.split(',')
  if note.length != 2 
      puts 'There is a problem!'
      next
  end
  thisNote = Note.new(note.first, note.last)
  puts thisNote.to_s
end

puts 'Enter new note title'
myTitle = gets.chomp
puts 'Enter new note body'
myBody = gets.chomp
myNote2 = Note.new(myTitle, myBody)
myNote2.write_to_file
