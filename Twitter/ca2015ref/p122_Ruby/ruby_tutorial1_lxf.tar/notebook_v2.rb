#!/usr/bin/ruby -w
#
# Second version of notebook program written for Linux Format Ruby 
# tutorial; introducing classes. 
# JPK Nov 2012

# Public: class to define a note. 
class Note
  @@notes = 0
  
  # Public: Initialize a Note.
  #
  # title - The String title of the Note.
  # body  - The String body of the Note.
  def initialize(title, body)
    @title  = title
    @body   = body
    @@notes += 1
  end

  # Public: Generate String version of Note.
  #
  # Returns the String version of the Note.
  def to_s
    "Note: #{@title}, #{@body}"
  end 

  # Public: Returns total number of Notes created.
  #
  # Returns the Integer number of Notes.
  def total_notes
    "Total notes: #{@@notes}"
  end

  # Public: Gets the String title and body of the Note.
  attr_reader :title, :body
  # Public: Sets the String title and body of the Note.
  attr_writer :title, :body
end

myNote = Note.new("Note 1", "this is a note")
puts myNote.inspect
puts myNote.to_s
puts myNote.title
puts myNote.body
myNote.title = "Note 1 edited"
puts "New title is: " + myNote.title

puts "Enter new note title"
myTitle = gets.chomp
puts "Enter new note body"
myBody = gets.chomp
myNote2 = Note.new(myTitle, myBody)
puts myNote2.to_s
puts myNote2.title
puts myNote2.body
puts myNote.total_notes

