#!/usr/bin/ruby -w
#
# Very basic first version of notebook program. 
# Written for Linux Format Ruby tutorial. 
# JPK Nov 2012

nbk = File.open('notebook.txt', 'a')
nbk.puts 'My first note'
nbk.puts 'My second note'
nbk.close

nbk = File.open('notebook.txt', 'a+')
nbk.rewind
while line = nbk.gets do
  puts line
end

puts 'Enter a new note'
nbk.puts gets
nbk.close
