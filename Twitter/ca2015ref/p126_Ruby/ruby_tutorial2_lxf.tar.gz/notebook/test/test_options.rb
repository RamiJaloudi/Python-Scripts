require 'test/unit'
require 'shoulda'
require_relative '../lib/notebook/options'

class TestOptions < Test::Unit::TestCase
  
  context "specifying no notebook" do
    should "return default" do
      opts = Notebook::Options.new([])
      assert_equal Notebook::Options::DEFAULT_NOTEBOOK, opts.notebook
    end
  end

  context "specifying a notebook" do
    should "return it" do
      opts = Notebook::Options.new(["-n", "test_notebook"])
      assert_equal "test_notebook", opts.notebook
    end
  end
end

