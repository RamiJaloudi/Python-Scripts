require 'test/unit'
require 'shoulda'
require_relative '../lib/notebook/note'

class TestNote < Test::Unit::TestCase
    
    # Removed when 'total notes' value removed from Note class
  #context "With 0 notes" do
  #    should "have total notes return 0" do
  #        assert_equal "Total notes: 0", Notebook::Note.total_notes
  #    end
  #end

  context "With notes" do
      setup do
          @title = "test_title"
          @body = "test_body"
          @test_note = Notebook::Note.new(@title, @body)
          @notebook_file = "notebook.txt"
      end

      should "output title and body string for to_s" do
        assert_equal "Note: #{@title}, #{@body}", @test_note.to_s
      end

      should "have last line of file equal to test note values after write_to_file" do
          @test_note.write_to_file(@notebook_file)
          @last_line = `tail -n 1 #{@notebook_file}`
          assert_equal "#{@title},#{@body}", @last_line.chomp
      end

    # Removed when 'total notes' value removed from Note class
      #should "have total_notes return 2" do
      #    assert_equal "Total notes: 2", Notebook::Note.total_notes
      #end
  end
end

