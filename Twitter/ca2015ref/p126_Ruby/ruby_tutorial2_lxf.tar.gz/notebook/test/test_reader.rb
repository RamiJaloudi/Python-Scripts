require 'test/unit'
require 'shoulda'
require_relative '../lib/notebook/reader'

class TestReader < Test::Unit::TestCase
  context "read" do
      should "return nothing when reading test file" do
        test_file = "testfile"
        note = "Test Note,test body"
        File.open(test_file, 'w') {|f| f.write(@note) }
        reader = Notebook::Reader.new(test_file)
        assert_equal nil, reader.read
        File.delete(test_file)
      end 
  end 
end

