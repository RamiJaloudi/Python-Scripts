module Notebook
  # Public: class to define a note. 
  class Note
      
    # Public: Initialize a Note.
    #
    # title - The String title of the Note.
    # body  - The String body of the Note.
    def initialize(title, body)
      @title  = title
      @body   = body
    end
    
    # Public: Gets/Sets the String title and body of the Note.
    attr_accessor :title, :body
    
    # Public: Generate String version of Note.
    #
    # Returns the String version of the Note.
    def to_s
      "Note: #{title}, #{body}"
    end 

    # Public: Write Note to file.
    #
    # Returns nothing.
    def write_to_file(file)
      File.open(file, 'a+') { |f| f.puts(@title + ',' + @body) }
    end

  end
end

