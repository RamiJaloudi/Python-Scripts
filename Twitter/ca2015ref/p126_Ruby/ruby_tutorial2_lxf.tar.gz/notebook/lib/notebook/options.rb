require 'optparse'

module Notebook
  class Options
    DEFAULT_NOTEBOOK = "notebook.txt"
    attr_reader :notebook, :add, :read

    def initialize(argv)
      @notebook = DEFAULT_NOTEBOOK
      parse(argv)
    end

    private
    def parse(argv)
      @add = false
      @read = false
      OptionParser.new do |opts|
        opts.banner = "Usage: notebook [ options ]"

        opts.on("-n", "--notebook PATH", String, "Path to notebook file") do |notebook|
          @notebook = notebook
        end

        opts.on("-a", "--add", "Add a note") { @add = true }

        opts.on("-r", "--read", "Read back notes") { @read = true }
        
        opts.on_tail("-h", "--help", "Show this message") do
          puts opts
          exit
        end


        begin      
          opts.parse!(argv)
        rescue OptionParser::InvalidOption => e
          puts e
          puts opts
          exit(1)
        end
      end
    end
  end
end

