require_relative 'note'
require_relative 'reader'
require_relative 'options'

module Notebook
  class Runner
    attr_reader :options

    def initialize(argv)
      @options = Options.new(argv)
    end

    def run
      reader = Reader.new(@options.notebook)
      if @options.read 
        reader.read
      end
      if @options.add  
        puts 'Enter new note title'
        title = gets.chomp
        puts 'Enter new note body'
        body = gets.chomp
        note = Note.new(title, body)
        note.write_to_file(@options.notebook)
      end
    end
  end
end


