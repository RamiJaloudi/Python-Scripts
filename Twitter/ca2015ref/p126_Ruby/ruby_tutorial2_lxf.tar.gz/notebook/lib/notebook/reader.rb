module Notebook
  # Public: class to read back notes from a file
  class Reader

    # Public: initialize the reader
    #
    # file - The String name of the file to read in from
    def initialize(file)
      @file = file
    end

    # Public: read back from the notebook file
    #
    # Returns nothing
    def read
      File.open(@file, 'a+') do |f|
        while line = f.gets do
          note = line.split(',')
          if note.length != 2
            puts "There is a problem!"
            next
          end
          puts Note.new(note.first, note.last).to_s
        end
      end
    end
  end
end



